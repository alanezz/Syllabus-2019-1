# Consulta 5 (vacía)

```sql
select u.* from usuario u, registro reg, sendero s where u.uid = reg.uid and reg.estado = 'en ruta' and reg.sid = s.sid and s.largo = (select max(sendero.largo) from sendero)
```
