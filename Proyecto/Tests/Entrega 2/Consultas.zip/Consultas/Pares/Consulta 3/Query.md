# Consulta 3

```sql
select v.nombre from vino v, enoturismo et, enovino ev where et.nombre = 'TOUR ASCENSO AL TAJO LAGARÍN DE SAN AMBROSIO' and v.cepa like '%TANNAH%'  and et.eid = ev.eid and ev.vinoid = v.vinoid;
```

Se prueba con tour "TOUR ASCENSO AL TAJO LAGARÍN DE SAN AMBROSIO", y con 
cepa 'TANNAH'
