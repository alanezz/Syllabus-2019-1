# Consulta 4
```sql
select v.nombre as nombre_vina, vn.* from vina v, vino vn where v.vid = vn.vid and vn.precio = (select max(vino.precio) from vino);
```
