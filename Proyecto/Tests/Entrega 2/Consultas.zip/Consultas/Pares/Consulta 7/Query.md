# Consulta 7
```sql
select parq.nombre, count(s.sid), sum(s.largo) from parque_nacional parq, sendero s where parq.pid =20 and s.pid = parq.pid group by s.pid, parq.nombre;
```

ID de parque escogido es 20
