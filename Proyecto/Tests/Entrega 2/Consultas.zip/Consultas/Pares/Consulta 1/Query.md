# Consulta 1

```sql
select s.* from sendero s, registro r where r.sid = s.sid and r.estado='finalizado' and r.uid = 40
```

Se prueba con usuario 40
