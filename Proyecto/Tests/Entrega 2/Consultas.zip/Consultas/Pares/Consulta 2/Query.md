# Consulta 2

```sql
select v.nombre from vina v where v.rid = 6 union select p.nombre from parque_nacional p where p.rid = 6
```
