# Consulta 8

Con `i=4`

```sql
select send.* from sendero send where send.largo = (select sendero.largo from sendero order by sendero.largo desc offset 4 limit 1)
```
