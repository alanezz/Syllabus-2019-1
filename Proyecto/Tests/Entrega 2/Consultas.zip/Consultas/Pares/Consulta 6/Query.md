# Consulta 6
```sql

select s.* from sendero s, (select reg.sid, count(reg.uid) cnt from registro reg where reg.estado='perdido' group by reg.sid) as cuenta where s.sid = cuenta.sid group by s.sid, cuenta.cnt having cuenta.cnt = max(cuenta.cnt);
```
