# Consulta 7
```sql
select u.nombre, hab.precio from usuario u, habitacion hab, reserva resv where resv.uid = u.uid and hab.habid = resv.habid and resv.resvid = 10;
```

ID de reserva usado 10
