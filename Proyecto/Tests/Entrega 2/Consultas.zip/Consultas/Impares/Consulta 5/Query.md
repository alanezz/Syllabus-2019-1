# Consulta 5

```sql
select r.rid, max(cuentas.cnt) from region r, (select resv.habid, h.rid, count(resv.resvid) cnt from reserva resv, hotel h, habitacion hab  where resv.habid = hab.habid and h.hid = hab.hid group by resv.habid, h.rid order by cnt desc) as cuentas where cuentas.rid = r.rid group by r.rid;
```
