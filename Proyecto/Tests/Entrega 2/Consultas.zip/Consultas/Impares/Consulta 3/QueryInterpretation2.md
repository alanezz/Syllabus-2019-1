# Consulta 3 Segunda Interpretacion
```sql
select r.* from reserva r where r.uid = 1 and r.fecha_fin >= '2027-01-01' and r.fecha_fin <= '2072-12-12';
```

ID de usuario 1, fechas entre 01/01/2027 hasta 12/12/2072
