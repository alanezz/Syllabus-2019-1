# Consulta 3

```sql
select r.* from reserva r where r.uid = 1 and r.fecha_inicio >= '2027-01-01' and r.fecha_inicio <= '2072-12-12';
```

ID de usuario 1, fechas entre 01/01/2027 hasta 12/12/2072
