# Consulta 6 (resultado vacío)
```sql
select resv.uid from reserva resv, hotel hot, habitacion habi where resv.habid = habi.habid and habi.hid = hot.hid and hot.hid = 2 and habi.precio = (select min(hab.precio) from hotel h, habitacion hab where hab.hid = h.hid and h.rid = 2) group by resv.uid, habi.precio;
```
