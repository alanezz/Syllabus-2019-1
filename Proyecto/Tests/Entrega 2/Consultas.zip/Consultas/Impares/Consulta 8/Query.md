# Consulta 7

Con `i=4`

```sql
select hab.* from habitacion hab where hab.precio = (select habitacion.precio from habitacion order by habitacion.precio desc offset 4 limit 1);
```
