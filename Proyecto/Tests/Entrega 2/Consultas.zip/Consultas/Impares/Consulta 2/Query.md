# Consulta 2

```sql
select h.*, ho.nombre nombre_hotel from habitacion h, hotel ho where ho.estrellas > 4 and h.hid = ho.hid;
```

Se prueba con 4 estrellas o más
