# Consulta 4
```sql
select t.* from tour t where t.aid in (select aid from agencia_region group by aid having count(rid) = 1)
```
