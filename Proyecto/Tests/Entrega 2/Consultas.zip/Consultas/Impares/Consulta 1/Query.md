# Consulta 1

Query:

```sql
select plato.* from plato, restaurant x where x.restid = plato.restid and x.rid = 1;
```

Se prueba con la región 1
